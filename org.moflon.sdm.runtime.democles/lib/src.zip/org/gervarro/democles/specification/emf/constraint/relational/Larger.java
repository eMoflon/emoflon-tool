/**
 */
package org.gervarro.democles.specification.emf.constraint.relational;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Larger</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gervarro.democles.specification.emf.constraint.relational.RelationalConstraintPackage#getLarger()
 * @model kind="class"
 * @generated
 */
public class Larger extends RelationalConstraint {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Larger() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RelationalConstraintPackage.Literals.LARGER;
	}

} // Larger
