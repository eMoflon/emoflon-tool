/**
 */
package org.gervarro.democles.specification.emf.constraint.relational;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Larger Or Equal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.gervarro.democles.specification.emf.constraint.relational.RelationalConstraintPackage#getLargerOrEqual()
 * @model kind="class"
 * @generated
 */
public class LargerOrEqual extends RelationalConstraint {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LargerOrEqual() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RelationalConstraintPackage.Literals.LARGER_OR_EQUAL;
	}

} // LargerOrEqual
