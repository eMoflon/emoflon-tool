package org.gervarro.democles.plan;

public enum OperationCategory {
	PAST,
	PRESENT,
	FUTURE;
}
